#ifndef GLAM2_SCAN_OUTPUT_H
#define GLAM2_SCAN_OUTPUT_H

#include <stdio.h>
#include "glam2_scan.h"

void print_hits(FILE *fp, const alignment *alns, const data *d);

#endif
