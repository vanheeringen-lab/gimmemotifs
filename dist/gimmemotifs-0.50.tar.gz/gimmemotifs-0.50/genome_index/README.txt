This directory contains the genome index-files for GimmeMotifs
